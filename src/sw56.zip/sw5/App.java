package sw5;

public class App {
    public static void main(String[] args) {
        Tour tour = new Tour("Matterhorn");
        tour.print();
    }
}
